import Home from "@/content/home/Home"

function page() {
    return (
        <div>
            <Home />
        </div>
    )
}

export default page

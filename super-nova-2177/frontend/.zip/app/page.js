"use client"
import ProposalWrapper from "@/content/proposal/ProposalWrapper";

function page() {
    return <ProposalWrapper />; 
}

export default page
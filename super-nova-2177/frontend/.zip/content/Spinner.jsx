function Spinner() {
    return (
        <img className="absolute -top-[-880px] left-50 text-center m-auto" src="./spinner.svg" alt="spinner" />
    )
}

export default Spinner
